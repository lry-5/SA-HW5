/*
 * Copyright 2017 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.hateoas.examples;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * Domain object representing a company employee. Project Lombok keeps actual
 * code at a minimum. {@code @Data} - Generates getters, setters, toString,
 * hash, and equals functions {@code @Entity} - JPA annotation to flag this
 * class for DB persistence {@code @NoArgsConstructor} - Create a constructor
 * with no args to support JPA {@code @AllArgsConstructor} - Create a
 * constructor with all args to support testing
 * {@code @JsonIgnoreProperties(ignoreUnknow=true)} When converting JSON to
 * Java, ignore any unrecognized attributes. This is critical for REST because
 * it encourages adding new fields in later versions that won't break. It also
 * allows things like _links to be ignore as well, meaning HAL documents can be
 * fetched and later posted to the server without adjustment.
 *
 * @author Greg Turnquist
 */

/**
 * @param name 读取的txt文件路径
 * @return
 */

@Data
@Entity
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@AllArgsConstructor
class FileInfo {

    @Id
    @GeneratedValue
    private Long id;

    private String name;
    private String description;
    private String[] definitions=new String[4];
    // private String sex;
    // private String birthday;
    // private String birthPlace;
    // private String dept;

    /**
     * Useful constructor when id is not yet known.
     * 
     * @param firstName
     * @param lastName
     * @param role
     */
    // Employee(String firstName, String lastName, String role) {

    // this.firstName = firstName;
    // this.lastName = lastName;
    // this.role = role;
    // }

    // public String getName(){
    // return firstName + " " + lastName;
    // }
    FileInfo() {
        this.name = "";
        this.description="";
        // this.sex = "";
        // this.birthday = "";
        // this.birthPlace = "";
        // this.dept = "";
    }

    FileInfo(String name, String description,String [] list) {
        // this.id=id;
        this.name = name;
        this.description=description;
        this.definitions=list;
        // this.sex = sex;
        // this.birthday = bd;
        // this.birthPlace = bp;
        // this.dept = dept;
    }

    public void setId(long id){
        this.id=id;
    }

    public Long getId(){
        return id;
    }

    public void setName(String str){
        name=str;
    }

    public String getName(){
        return name;
    }

    public void setDescription(String str){
        description=str;
    }

    public String getDescription(){
        return description;
    } 

    public void setDefinitions(String []list){
        definitions=list;
    }

    public String[] getDefinitions(){
        return definitions;
    }

    public String toStr() {
        return id + "," + description + "," + definitions[0] + "," + definitions[1] 
        + "," + definitions[2] + "," + definitions[3];
    }
}
