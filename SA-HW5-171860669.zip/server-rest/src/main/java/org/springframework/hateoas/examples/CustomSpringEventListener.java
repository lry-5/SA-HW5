package org.springframework.hateoas.examples;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

@Component
@EnableAsync
public class CustomSpringEventListener {    

    @EventListener
    @Async
    public void processCustomEvent(CustomSpringEvent event) throws IOException {

        System.out.println("listener***********************");
        
        // 创建ProcessBuilder对象
        ProcessBuilder processBuilder = new ProcessBuilder();
        // 设置执行的第三方程序(命令)
       
        processBuilder.command(event.getMessage());
        // 将标准输入流和错误输入流合并，通过标准输入流读取信息就可以拿到第三方程序输出的错误信息、正常信息
        processBuilder.redirectErrorStream(true);

        // 启动一个进程
        Process process = processBuilder.start();
        // 由于前边将错误和正常信息合并在输入流，只读取输入流
        InputStream inputStream = process.getInputStream();
        // 将字节流转成字符流
        InputStreamReader reader = new InputStreamReader(inputStream, "gbk");
        // 字符缓冲区
        char[] chars = new char[1024];
        int len = -1;
        while ((len = reader.read(chars)) != -1) {
            String string = new String(chars, 0, len);
            System.out.println(string);
        }

        inputStream.close();
        reader.close();

    }
}