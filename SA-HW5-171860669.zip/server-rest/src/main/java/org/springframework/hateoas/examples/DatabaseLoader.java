/*
 * Copyright 2017 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.hateoas.examples;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

/**
 * Pre-load some data using a Spring Boot {@link CommandLineRunner}.
 *
 * @author Greg Turnquist
 */
@Component
class DatabaseLoader {

	/**
	 * Use Spring to inject a {@link EmployeeRepository} that can then load data.
	 * Since this will run only after the app is operational, the database will be
	 * up.
	 *
	 * @param repository
	 */
	@Bean
	CommandLineRunner init(FileInfoRepository repository) {
		String[] ls={"360p","720p"};
		// return args -> {
		// 	repository.save(new Employee("Frodo", "Baggins", "ring bearer"));
		// 	repository.save(new Employee("Bilbo", "Baggins", "burglar"));
		// };
		return args -> {
			repository.save(new FileInfo("VID_20200506_192048.mp4","男", ls));
			repository.save(new FileInfo("VID_20200506_192048_test.mp4","男", ls));
		};
	}

}
