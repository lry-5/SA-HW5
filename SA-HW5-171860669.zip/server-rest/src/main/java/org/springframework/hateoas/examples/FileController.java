/*
 * Copyright 2017 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.hateoas.examples;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.IanaLinkRelations;
import org.springframework.hateoas.Link;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.beans.factory.annotation.Autowired;

// class FileInfo {
// 	public String name;
// 	public List<String> definitions = new ArrayList<>();
// 	public String description;
// }

/**
 * Spring Web {@link RestController} used to generate a REST API.
 *
 * @author Greg Turnquist
 */

@RestController
@CrossOrigin
class FileController {
	@Autowired
	private SomeEventSource source;

	private String rootPath = System.getProperty("user.dir") + "/";
	private String assetPath = rootPath + "videos/";
	// private String video_info = "video_info.txt";
	private final FileInfoRepository repository;
	// private List<FileInfo> fileInfoes = new ArrayList<>();

	FileController(FileInfoRepository repository) {
		// FileController(FileInfoRepository repository) {
		this.repository = repository;

		File file = new File(assetPath);
		if (!file.exists())// 文件夹不存在就创建
		{
			file.mkdirs();
		}		
	}

	public String getSuffix(String name) {
		return name.substring(name.lastIndexOf(".") + 1, name.length());
	}

	public boolean checkSuffix(String suffix) {
		boolean res = true;
		if (suffix.equals("") || !suffix.equals("mp4") && !suffix.equals("WebM") && !suffix.equals("Ogg")) {
			System.out.println("视频格式不对");
			// if (suffix.equals("") || !suffix.equals("mp4") && !suffix.equals("mov") &&
			// !suffix.equals("flv")
			// && !suffix.equals("avi") && !suffix.equals("mpeg4") && !suffix.equals("mpg"))
			// {
			res = false;
		}
		return res;

	}

	@PostMapping("/upload")
	public void upload(@RequestParam(value = "file", required = false) MultipartFile multipartFile,
			@RequestParam(value = "description", required = false) String description) {		
		// 视频上传
		// 获取原文件名
		if (description == null) {
			System.out.println("desp null");
			description = "";
		}
		String name = multipartFile.getOriginalFilename();
		// 获取文件后缀
		String suffix = name.substring(name.lastIndexOf(".") + 1, name.length());
		System.out.println(
				"upload***************************" + suffix + "  assetPath:" + assetPath + " dsp " + description);
		// 控制格式
		if (!checkSuffix(suffix)) {
			System.out.println("视频格式不对");
			return;
		}

		// 保存文件

		try {
			multipartFile.transferTo(new File(assetPath + name));

		} catch (IOException e) {
			e.printStackTrace();
		}

		// 将信息保存到repository
		String[] strs = { "360p", "720p" };
		FileInfo videoInfo = new FileInfo();
		videoInfo.setName(name);
		videoInfo.setDefinitions(strs);
		videoInfo.setDescription(description);

		repository.save(videoInfo);

		// 压缩视频
		List<String> cmdList = Arrays.asList(rootPath + "../HandBrakeCLI-1.3.2/HandBrakeCLI", "-i", assetPath + name,
				"-o", assetPath + "360p_" + name, "-e", "x264", "-l", "360", "-w", "640");
		// myCmd(cmdList);
		source.fireEvent(cmdList);
		cmdList = Arrays.asList(rootPath + "../HandBrakeCLI-1.3.2/HandBrakeCLI", "-i", assetPath + name, "-o",
				assetPath + "720p_" + name, "-e", "x264", "-l", "720", "-w", "1280");
		source.fireEvent(cmdList);
		// myCmd(cmdList);

	}

	@GetMapping("/infolist")
	ResponseEntity<CollectionModel<FileInfo>> findAllInfo() {
		// ResponseEntity<CollectionModel<String>> findAllName() {

		System.out.println("infolist********************");
		List<FileInfo> fileInfoes = new ArrayList<>();
		for (FileInfo info : repository.findAll()) {
			fileInfoes.add(info);
		}
		return ResponseEntity.ok( //
				new CollectionModel<>(fileInfoes));
	}

	@GetMapping("/get/{name}")
	void findOneFile(@PathVariable String name, HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		System.out.println("s name:" + name + "****   ");
		// String fullName=definition+(definition.isEmpty()?"":"_")+name;
		File file = new File(assetPath + name);
		// 判断文件是否存在如果不存在就返回
		if (!(file.exists() && file.canRead())) {
			// file = new File(path+"company/root.png");
			System.out.println("file not exist");
			return;
		}

		FileInputStream inputStream = new FileInputStream(file);
		byte[] data = new byte[(int) file.length()];
		int length = inputStream.read(data);
		inputStream.close();

		String rangeString = request.getHeader("Range");// 如果是video标签发起的请求就不会为null
		long range = Long.valueOf(rangeString.substring(rangeString.indexOf("=") + 1, rangeString.indexOf("-")));

		response.setContentType("video/" + getSuffix(name));// 设定输出的类型
		response.setHeader("Content-Disposition", "attachment;filename=" + name);
		response.setContentLength(length);//length是视频文件的大小

		response.setHeader("Content-Range", String.valueOf(range + (length-1)));//拖动进度条时的断点，其中length是上面的视频文件大小
		response.setHeader("Accept-Ranges", "bytes");

		OutputStream stream = response.getOutputStream();
		stream.write(data);
		stream.flush();
		stream.close();

		// return repository.findById(id) //
		// .map(student -> new EntityModel<>(student, //
		// linkTo(methodOn(FileInfoController.class).findOne(student.getId())).withSelfRel(),
		// //
		// linkTo(methodOn(FileInfoController.class).findAll()).withRel("students"))) //
		// .map(ResponseEntity::ok) //
		// .orElse(ResponseEntity.notFound().build());
	}

}
