package org.springframework.hateoas.examples;

import java.util.List;

import org.springframework.context.ApplicationEvent;

public class CustomSpringEvent extends ApplicationEvent {
    private static final long serialVersionUID = -1L;

    private List<String> message;

    public CustomSpringEvent(final Object source, final List<String> message) {
        super(source);
        this.message = message;
    }

    public List<String> getMessage() {
        return message;
    }

}