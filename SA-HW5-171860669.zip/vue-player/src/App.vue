<template>
  <div id="app" class="small-container">
    <h1>Player</h1>
    <video id="player" width="848" height="480" controls>
      <source :src="prefix+definition+'_'+fileName" />
      <!-- <source :src="videoUrl" /> -->
    </video>

    <table>
      <tr>
        <th>清晰度</th>
        <th>文件列表</th>
      </tr>
      <tr>
        <td>
          <select class="definition" v-model="definition" @change="updateVideoSrc(0)">
            <option v-for="item in definitions" :key="item" :label="item" :value="item"></option>
          </select>
        </td>
        <td style="width:80%">
          <select class="infoList" v-model="fileId" @change="updateVideoSrc(1)">
            <option
              v-for="item in fileInfoes"
              :key="item.id"
              :label="item.id+' '+item.name"
              :value="item.id"
            >            
            </option>
          </select>
        </td>
      </tr>
    </table>
    
  </div>
</template>

<script>
// import StudentTable from "./components/StudentTable.vue";
// import StudentForm from "./components/StudentForm.vue";

export default {
  name: "App",
  components: {},
  data() {
    return {
      fileId: 0,
      fileName: "",
      definition: "360p",
      definitions: Array,
      prefix: "http://localhost:8083/get/",
      videoUrl: "http://localhost:8083/get/360p_VID_20200506_192048.mp4",
      fileInfoes: Array
    };
  },

  mounted() {
    this.getInfoList();
  },

  methods: {
    updateVideoSrc(isOther) {
      // this.videoUrl=this.prefix+this.definition+"_"+this.fileName;

      let video = document.getElementById("player");//获得播放元素
      let currentTime = video.currentTime;

      this.fileInfoes.forEach(item => {
        if (this.fileId == item.id) {//找到选中的fileInfo
          this.fileName = item.name;
          this.definitions = item.definitions;
        }
      });

      video.src = this.prefix + this.definition + "_" + this.fileName;//修改视频源
      video.play();
      if (isOther == 0) {
        console.log("not other");
        video.currentTime = currentTime;//改清晰度时进度不变
      } else {
        //不同文件
        console.log("is other");
        video.currentTime = 0;//换其他视频时重新开始
      }
      this.getInfoList();
    },

    async getInfoList() {
      try {
        const response = await fetch("http://localhost:8083/infolist");
        const data = await response.json();
        this.fileInfoes = data._embedded.fileInfoes;
        console.log("get Info List***" + this.fileInfoes[0].definitions);
      } catch (error) {
        console.error(error);
      }
    }
  }
};
</script>

<style>
button {
  background: #009435;
  border: 1px solid #009435;
}

.small-container {
  max-width: 848px;
}

/* .definition{
  width:48px
}

.infoList{
  width:700px
} */
</style>
